import { createBrowserHistory } from 'history';

const createBrowserHistory = (props) => (
    <div>broswer history
    </div>
);

export default createBrowserHistory();