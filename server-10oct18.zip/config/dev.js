module.exports = {
    googleClientID:'111318676083-nkq8rt87uvtabbt4gfr27s1j6lm6sp01.apps.googleusercontent.com',
    googleClientSecret:'ZgJnSGXfOLKsGJmcfacBbINz',
    mongoURI : 'mongodb://hoa:password123@ds047935.mlab.com:47935/emaily-dev',
    cookieKey : 'dsafadsfkjadsnfladskjfnasdlz',
    stripePublishableKey : 'https://dashboard.stripe.com/account/apikeys',
    stripeSecretKey : 'sk_test_X4A4kS4Hf15sE8SskhGTmhj5'
};
