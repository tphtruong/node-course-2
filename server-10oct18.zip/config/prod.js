module.exports = {
    mongoURI : process.env.MONGO_URI,
    cookieKey : process.env.COOKIE_KEY,
    stripePublishableKey : process.env.STRIPE_PK,
    stripeSecretKey : process.env.STRIPE_SECRET
};